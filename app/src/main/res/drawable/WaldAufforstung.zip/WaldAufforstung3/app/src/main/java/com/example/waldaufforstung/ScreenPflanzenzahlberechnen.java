package com.example.waldaufforstung;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ScreenPflanzenzahlberechnen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_pflanzenzahlberechnen);

        getSupportActionBar().setTitle("Pflanzenanzahl berechnen");


    }
}